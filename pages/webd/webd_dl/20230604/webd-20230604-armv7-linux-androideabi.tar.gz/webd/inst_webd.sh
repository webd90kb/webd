#!/bin/sh
dst=/data/local/tmp
user="user1"
pass="pass1"
adb push webd ${dst}
adb shell "chmod 555 ${dst}/webd; killall webd; ifconfig; mkdir -pv /sdcard/.Trash; nohup ${dst}/webd -g0 -u rlumS:${user}:${pass} -w /sdcard &> /dev/null &"
read -p 'Press any key to exit.'
